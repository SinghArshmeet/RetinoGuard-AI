---
name: Clinical Diagnostic Precision
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#bfc7d2'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#89929b'
  outline-variant: '#3f4850'
  surface-tint: '#93ccff'
  primary: '#93ccff'
  on-primary: '#003351'
  primary-container: '#3198dc'
  on-primary-container: '#002c47'
  inverse-primary: '#006398'
  secondary: '#ffb3ad'
  on-secondary: '#68000a'
  secondary-container: '#a40217'
  on-secondary-container: '#ffaea8'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#ffb3ad'
  on-secondary-fixed: '#410004'
  on-secondary-fixed-variant: '#930013'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  metric-md:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  metric-sm:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.5rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an ultra-high-reliability, diagnostic-grade environment engineered specifically for pediatric ocular oncology and surgical decision support. The aesthetic combines surgical minimalism, high-contrast information density, and focused telemetry instrumentation. It avoids generic software tropes in favor of an ergonomic, low-eye-strain optical laboratory interface optimized for prolonged inspection of high-resolution digital fundus photography, ultra-widefield imaging, and optical coherence tomography (OCT).

The visual tone conveys absolute clinical fidelity, immediate risk triage, and total algorithmic transparency. Every surface, contrast step, and indicator is tuned to eliminate perceptual ambiguity in high-stakes oncology decisions—from early-stage leukocoria screening to staging intraocular retinoblastoma (ICRB / Reese-Ellsworth systems) and tracking bilateral germline RB1 mutations.

## Colors

The palette is anchored by a deep zinc-950 (`#09090B`) bedrock and zinc-900 (`#18181B`) elevated surfaces, bounded by structural zinc-800 (`#27272A`) hairpins to support deep retinal visualization under subdued reading room lighting.

Diagnostic accents carry uncompromising semantic contracts:
- **Primary & AI Instrumentation (`#0284C7`, accent `#38BDF8`):** Applied to active scan boundaries, machine segmentation contours, and primary diagnostic confirmative workflows.
- **Malignant Alerts & High Risk (`#EF4444`):** Reserved exclusively for confirmed tumor masses, vitreous seeding detection, critical staging escalations, and urgent alerts.
- **Safe Controls & Normal Baselines (`#10B981`):** Applied to benign findings, validated clearance checkpoints, and normal retinal architecture.
- **Explainability & Saliency (`#F59E0B`):** Assigned to Grad-CAM saliency heatmaps, model uncertainty overlays, and feature attribution highlights.
- **Genomic & Germline Diagnostics (`#6366F1`):** Designated for germline RB1 allele status, bilateral predisposition badges, and pedigree linkage data.

Text follows a calibrated hierarchy: high-contrast clinical white (`#FAFAFA`) for critical readings, muted zinc-400 (`#A1A1AA`) for meta-labels, and dimmed zinc-600 (`#52525B`) for structural framing.

## Typography

The typographic hierarchy establishes clear boundaries between structural navigation, diagnostic analysis, and technical clinical metrics:
- **Headlines (Plus Jakarta Sans):** Provides structural weight and ergonomic legibility in high-density clinical views without appearing sterile.
- **Body & Clinical Narrative (Inter):** Highly legible neutral grotesque engineered for rapid scanning of pathology impressions, triage summaries, and history notes.
- **Telemetry & Identity (JetBrains Mono):** Dedicated to accession numbers, DICOM tags, calibration coefficients, ICRB staging codes, confidence percentages, and genomic coordinates. Tabular figures ensure aligned vertical telemetry across scanning sweeps.

## Layout & Spacing

The viewport architecture leverages a high-density, 12-column adaptive diagnostic grid optimized for dual-monitor medical displays (1440px and 4K DICOM displays) down to bedside tablet devices:
- **Diagnostic Canvas:** Center workspace maintains flexible 6- to 8-column allocations dedicated to canvas viewports (fundus, OCT, B-scan ultrasound).
- **Inspection Rails:** Fixed 360px-to-420px contextual side panels preserve persistent patient telemetry, RB1 gene tracking, and AI layer controls.
- **Responsive Adaptations:** At widths below 1024px, the layout transitions to a stacked single-column workflow with collapsible drawer telemetry to safeguard canvas magnification and inspection integrity.

## Elevation & Depth

Visual hierarchy operates via low-contrast structural outlines, tonal background shifts, and surgical luminance layering rather than drop shadows:
- **Base Canvas (Level 0):** Pure `#09090B` absorbs peripheral light, creating a focused frame around retinal imagery.
- **Inspection Cards & Tools (Level 1):** Tinted `#121215` with crisp `1px` borders in `#27272A`. Zero diffuse shadows.
- **Active Reticles & Floating Controls (Level 2):** `#18181B` with an enhanced `1px` border in `#3F3F46` and a focused 12px ambient rim blur (`rgba(0, 0, 0, 0.45)`).
- **Critical Diagnostics (Alert Elevation):** Bounding boxes, alert popovers, and urgent risk interventions utilize a 1px solid halo of the respective semantic color (`#EF4444`, `#0284C7`, or `#F59E0B`) accompanied by a subtle 8px localized outer glow at 20% opacity.

## Shapes

The interface employs a disciplined, geometric shape scale (Level 1 - Soft) to maximize screen real estate and convey surgical precision:
- Base components (buttons, tags, input fields, and metric modules) use an exact `0.25rem` (4px) corner radius.
- Diagnostic modals, image toolbars, and primary canvas viewports utilize `0.5rem` (8px) corner radius.
- Bounding boxes, segmentation callouts, and multi-slice view markers remain strictly non-rounded (`0px`) to prevent geometric distortion over retinal lesions.

## Components

### Buttons & Surgical Actions
- **Primary AI Action:** Filled `#0284C7` with `#FFFFFF` text, 4px radius, `space-xs` vertical by `space-md` horizontal padding. Hover states escalate to `#38BDF8`.
- **Destructive / Urgent Staging:** Solid `#EF4444` with `#FFFFFF` text for irreversible clinical triggers (e.g., "Confirm Tumor Seeding Stage E").
- **Secondary / Inspection:** Ghost style with `#18181B` background, `1px` solid `#27272A` border, and `#FAFAFA` text. Focus rings display a 2px outer cyan ring (`#0284C7`).

### Diagnostic Chips & Staging Badges
- Compact height (20px-24px), monospaced `label-code` typography.
- **Malignancy Flag:** `#EF4444` tinted background at 12% opacity with solid `1px` `#EF4444` border and white text.
- **Germline RB1 Status:** `#6366F1` background at 15% opacity with crisp `#818CF8` text.
- **Saliency Model Confidence:** Background `#18181B`, border `#F59E0B` (left border 3px solid), showing metric value in `JetBrains Mono`.

### Input & Calibration Fields
- Monospaced metric inputs, height 36px, structured on `#0E0E11` surfaces with `#27272A` borders.
- When focused, borders snap to solid `#0284C7` with no offset glow to preserve metric border precision.

### Retinal Viewport & Annotation Bounding Boxes
- Direct canvas overlays utilize ultra-thin 1.5px vector strokes in `#38BDF8` with corner anchor crosshairs.
- Malignant seed detections render in pulsed `#EF4444` 1.5px bounding hulls with translucent 8% fill.
- Heatmap explainability (Grad-CAM) triggers a controlled non-destructive thermal blend over fundus layers with a sliding toggle indicator.